package ui;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
public class AddResidentPanel extends JPanel {

    private JTextField nameField;
    private JTextField ageField;

    public AddResidentPanel() {
        setLayout(new GridLayout(3, 2));

        JLabel nameLabel = new JLabel("Name:");
        nameField = new JTextField();
        JLabel ageLabel = new JLabel("Age:");
        ageField = new JTextField();
        JButton addButton = new JButton("Add Resident");

        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String name = nameField.getText();
                int age = Integer.parseInt(ageField.getText()); // Convert text to int (you might need validation)

                // Add logic to save to database or perform actions with the new resident data
                // For example, you can print the new resident's details for now
                System.out.println("New Resident Added:");
                System.out.println("Name: " + name);
                System.out.println("Age: " + age);
            }
        });

        add(nameLabel);
        add(nameField);
        add(ageLabel);
        add(ageField);
        add(addButton);
    }
}
