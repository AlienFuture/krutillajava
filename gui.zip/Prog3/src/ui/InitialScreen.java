package ui;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class InitialScreen extends JFrame {


    private ImageIcon titleIcon;
    private JLabel titleLabel;

    public InitialScreen() {
        setTitle("KÜF");
        setSize(1280, 720);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false); // Set window resizable to false

        JPanel backgroundPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                ImageIcon image = new ImageIcon(getClass().getResource("/images/bg.jpg"));
                Image img = image.getImage();
                g.drawImage(img, 0, 0, getWidth(), getHeight(), this);
            }
        };
        getContentPane().setLayout(new BorderLayout());
        getContentPane().add(backgroundPanel);

        titleIcon = new ImageIcon(getClass().getResource("/images/titleimg.png"));
        titleLabel = new JLabel(titleIcon);

        placeComponents(backgroundPanel);

        setVisible(true);
    }

    private void placeComponents(JPanel panel) {
        JPanel titlePanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        titlePanel.setOpaque(false); // Make titlePanel transparent
        titlePanel.add(titleLabel);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        buttonPanel.setOpaque(false); // Make buttonPanel transparent
        JButton loginButton = new JButton("Bejelentkezés");
        JButton exitButton = new JButton("Exit");
        buttonPanel.add(loginButton);
        buttonPanel.add(exitButton);

        panel.setLayout(new BorderLayout());
        panel.add(titlePanel, BorderLayout.NORTH);
        panel.add(buttonPanel, BorderLayout.SOUTH);

        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                LoginScreen loginScreen = new LoginScreen(InitialScreen.this); // Pass reference to InitialScreen
                loginScreen.setVisible(true);
            }
        });

        exitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new InitialScreen());
    }

    @Override
    public void validate() {
        super.validate();
        if (titleIcon != null && titleLabel != null) {
            int width = getWidth() / 2;
            int height = getHeight() / 2;
            Image img = titleIcon.getImage().getScaledInstance(width, height, Image.SCALE_SMOOTH);
            titleLabel.setIcon(new ImageIcon(img));
        }
    }
}