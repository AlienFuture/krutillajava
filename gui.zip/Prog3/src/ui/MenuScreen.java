package ui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MenuScreen extends JFrame {

    public MenuScreen() {
        setTitle("Menu");
        setSize(400, 300);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JButton motdButton = new JButton("MOTD");
        JButton addResidentButton = new JButton("Add New Resident");
        JButton changeDataButton = new JButton("Change Data");
        JButton logoutButton = new JButton("Logout");

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(4, 1));
        panel.add(motdButton);
        panel.add(addResidentButton);
        panel.add(changeDataButton);
        panel.add(logoutButton);

        add(panel);

        addResidentButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFrame addResidentFrame = new JFrame("Add New Resident");
                addResidentFrame.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
                addResidentFrame.setSize(300, 200);
                addResidentFrame.setLocationRelativeTo(null);
                addResidentFrame.add(new AddResidentPanel());
                addResidentFrame.setVisible(true);
            }
        });

        addResidentButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(MenuScreen.this, "Add new resident");
            }
        });

        changeDataButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(MenuScreen.this, "Change Data");
            }
        });

        logoutButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                InitialScreen initialScreen = new InitialScreen();
                initialScreen.setVisible(true);
            }
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new MenuScreen());
    }
}