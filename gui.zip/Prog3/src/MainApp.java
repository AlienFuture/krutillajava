import javax.swing.*;
import ui.InitialScreen;

public class MainApp {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            InitialScreen initialScreen = new InitialScreen();
            initialScreen.setVisible(true); // Show the InitialScreen
        });
    }
}